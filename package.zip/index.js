// server.js
import express from "express";
import cors from "cors";
import connectDB from "./configs/db.js";
import dotenv from "dotenv";

import authRoutes from "./routes/authenticationRoutes.js";
import postRoutes from "./routes/postRoutes.js";

import fs from "fs";
import path from "path";

const uploadDir = path.join(process.cwd(), "uploads");

if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
}

// Load env variables
dotenv.config();
// Connect to MongoDB
connectDB();
const app = express();
app.get("/health", (req, res) => res.sendStatus(200));

app.get("/", (req, res) => {
  res.status(200).send("LifeVault is running");
});
// Middleware
app.use(cors());
app.use(express.json());
app.use("/uploads", express.static("uploads"));

app.use("/api/auth", authRoutes);
app.use("/api/post", postRoutes);

// Start server
const PORT = process.env.PORT || 3000;
app.listen(PORT, "0.0.0.0", () => {
  console.log(`Server running on port ${PORT}`);
});

// app.get('/health', (req, res) => res.sendStatus(200));

// Optional: root route for ALB health check
